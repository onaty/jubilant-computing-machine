//
//  INSCameraLive.h
//  INSCameraSDK
//
//  Created by zeng bin on 1/18/18.
//  Copyright © 2018 insta360. All rights reserved.
//

#ifndef INSCameraLive_h
#define INSCameraLive_h

#import <INSCameraSDK/INSFlatRTMPStreamer.h>
#import <INSCameraSDK/INSScreenRTMPStreamer.h>
#import <INSCameraSDK/INSH264RTMPStreamer.h>

#endif /* INSCameraLive_h */
